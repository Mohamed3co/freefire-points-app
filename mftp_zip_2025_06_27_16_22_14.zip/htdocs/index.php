<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
        <title>شحن جواهر فري فاير</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                
                    <!-- ربط ملف CSS -->
                        <link rel="stylesheet" href="assets/css/style.css">
                        </head>
                        <body>

                            <div class="container">
                                    <h1>شحن جواهر فري فاير</h1>
                                            <p id="points-display">جاري تحميل نقاطك...</p>

                                                    <form id="claim-form">
                                                                <input type="text" id="user-id" placeholder="أدخل معرفك" required>
                                                                            <button type="submit">طلب الشحن</button>
                                                                                    </form>

                                                                                            <div id="offers-container">
                                                                                                        <p>جاري تحميل العروض...</p>
                                                                                                                </div>
                                                                                                                    </div>

                                                                                                                        <!-- ربط ملف JS -->
                                                                                                                            <script src="assets/js/main.js"></script>
                                                                                                                            </body>
                                                                                                                            </html>